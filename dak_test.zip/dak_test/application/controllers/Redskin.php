<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Redskin extends CI_Controller {
	
	public static $q_num = 0;
	
	public static $q_id = 0;
	
	public function __construct(){
		parent::__construct();
		$this->load->model("redskin_model");	
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data = array();
		$data_fr = array();
		$friend_ar = array();
		$friend_data = array();
		
		//Email Config.
		$config = Array(
		  'protocol' => 'smtp',
		  //'smtp_host' => 'ssl://smtp.gmail.com',
		  'smtp_host' => 'ssl://smtp.googlemail.com',
		  'smtp_port' => 465,
		  'smtp_user' => 'sibukumarantony@gmail.com', // change it to yours
		  'smtp_pass' => 'welcome@123', // change it to yours 
		  'mailtype' => "html",
		  'charset' => 'iso-8859-1'
		);
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");		
		$this->email->from('amitkbin@gmail.com', 'Amit Bhar');
		//End Email Config.
		
		$post_reg = $this->input->post('post_reg');	
		$guest_id = $this->input->post('guest_id');	
		if(isset($post_reg) && $post_reg=="insert"){
			$fname = $this->input->post('fname');
			$lname = $this->input->post('lname');
			$email = $this->input->post('email');
			$zip_code = $this->input->post('zip_code');
			$no_of_guest = $this->input->post('no_of_guest');
			$free_season_ticket_waitlist = $this->input->post('free_season_ticket_waitlist');
			$free_redskin_women_club = $this->input->post('free_redskin_women_club');
			$receive_special_offer = $this->input->post('receive_special_offer');
			$redskin_salute_military = $this->input->post('redskin_salute_military');
			
			if(!empty($guest_id)){
				$this->db->select("*");
				$this->db->where(array(
					 'id' => $guest_id
				));
				$query_guest = $this->db->get('guest');
				$res_guest = $query_guest->result();
				$fname = $res_guest[0]->fname;
				$lname = $res_guest[0]->lname;
				$email = $res_guest[0]->email;
			}
			
			$data = array(
				'fname' => $fname,
				'lname' => $lname,
				'email' => $email,
				'zip_code' => $zip_code,
				'no_of_guest' => $no_of_guest,
				'free_season_ticket_waitlist' => $free_season_ticket_waitlist,
				'free_redskin_women_club' => $free_redskin_women_club,
				'receive_special_offer' => $receive_special_offer,
				'redskin_salute_military' => $redskin_salute_military,
				'post_date' => date("Y-m-d")
			);
			
			$this->db->select("COUNT(*) AS dup_guest");
			$this->db->where(array(
				 'fname' => $fname,
				 'lname' => $lname,
				 'email' => $email,
				 'post_date' => date("Y-m-d")
			));
			$count_query_guest = $this->db->get('guest');
			$count_res_guest = $count_query_guest->result();
			
			if(empty($guest_id) || $guest_id==""){
				if($count_res_guest[0]->dup_guest >= 0){
					$this->db->insert('guest', $data);
					$guest_id = $this->db->insert_id();
					
					//Send Email
					$data_email = array(
						'guest_name'=> $fname.' '.$lname,
						'no_of_guests'=> $no_of_guest	
					 );
					 $subject = "Redskins Training Camp Pass";
					 $this->email->to($email);
					 $this->email->subject($subject);
					 $body_cont = $this->load->view('emails/ticket.php',$data_email,TRUE);
					 $this->email->message($body_cont); 
					 $this->email->send();
				} else {
					redirect('/redskin/index/');
				}					
			}
			
			
			
			if(!empty($guest_id)){
				
				$this->session->set_userdata('guest_id', $guest_id);
				if(!empty($_POST['registration']['guests']) && is_array($_POST['registration']['guests']) ){
					$start_pt = 0;
					$loop_run = 0;
					if(array_key_exists(1, $_POST['registration']['guests'])){
						$start_pt = 1;
						$loop_run = count($_POST['registration']['guests']);
					} else {
						$start_pt = 2;
						$loop_run = count($_POST['registration']['guests'])+1;
					}
					
					$friend_count = 0;
					for($k=$start_pt; $k<=$loop_run; $k++){
						$friend_data = array();
						if(array_key_exists($k, $_POST['registration']['guests'])){
							$friend_data = array(
								 'guest_id' => $guest_id,
								 'fname' => $_POST['registration']['guests'][$k]['firstName'],
								 'lname' => $_POST['registration']['guests'][$k]['lastName'],
								 'email' => $_POST['registration']['guests'][$k]['email'],
								 'post_date' => date("Y-m-d")
							);
							
							$this->db->select("COUNT(*) AS dup_frnd");
							$this->db->where(array(
								 'fname' => $_POST['registration']['guests'][$k]['firstName'],
								 'lname' => $_POST['registration']['guests'][$k]['lastName'],
								 'email' => $_POST['registration']['guests'][$k]['email'],
								 'post_date' => date("Y-m-d")
							));
							$count_query = $this->db->get('friends');
							$count_res = $count_query->result();
							
							if($count_res[0]->dup_frnd == 0 && count($friend_data) > 0){
								$friend_ar[$friend_count] = array(
										'guest_id' => $guest_id,
										'fname' => $_POST['registration']['guests'][$k]['firstName'],
										'lname' => $_POST['registration']['guests'][$k]['lastName'],
										'email' => $_POST['registration']['guests'][$k]['email']
								);
								$this->db->insert('friends', $friend_data);
								
								$friend_count++;
								
								//Send Email
								$data_email_friend = array(
									'guest_name'=> $_POST['registration']['guests'][$k]['firstName'].' '.$_POST['registration']['guests'][$k]['lastName'],
									'no_of_guests'=> 0	
								 );
								 $subject_friend = "Redskins Training Camp Pass";
								 $this->email->to($_POST['registration']['guests'][$k]['email']);
								 $this->email->subject($subject_friend);
								 $body_friend = $this->load->view('emails/ticket.php',$data_email_friend,TRUE);
								 $this->email->message($body_friend); 
								 $this->email->send();
								
								
							}
							
						}
						
						
					}
					
					if($friend_count == 0){
						$friend_ar[0] = array(
								'fname' => $fname,
								'lname' => $lname,
								'email' => $email
						);
					} else {
						$frnd_size = sizeof($friend_ar);
						$friend_ar[$frnd_size] = array(
								'fname' => $fname,
								'lname' => $lname,
								'email' => $email
						);
					}
					
				} else {
					$friend_ar[0] = array(
							'fname' => $fname,
							'lname' => $lname,
							'email' => $email
					);
				}
			}
			
			$data_fr['friend_ar'] = $friend_ar;
			$data_fr['guest_id'] = $guest_id;
			$this->load->view('final_page', $data_fr);
			//exit;
		} else {
			$this->load->view('index', $data);
		}
		
	}
	
	
}
