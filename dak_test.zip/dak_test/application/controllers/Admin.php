<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	public static $q_num = 0;
	
	public static $q_id = 0;
	
	public function __construct(){
		parent::__construct();
		$this->load->model("admin_model");	
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data = array();
		
		$this->load->view('admin/login', $data);		
	}
	
	//Authenticate
	public function log(){
		$data = array();
		
        if(isset($_POST) ){ 
            $query = $this->admin_model->validate_user();
            
            //-- if valid
            if(!empty($query) ){
                //echo "TESTY"; die;
                foreach($query as $row){
                    $session_data = array(
                        'id' => $row->id,
                        'name' => $row->full_name,
                        'username' =>$row->username,
                        'is_login' => TRUE
                    );
                    $this->session->set_userdata($session_data);
                    $url = base_url('admin/dashboard');
                }
				redirect(base_url() . 'admin/dashboard', 'refresh');
            }else{
               redirect(base_url() . 'admin', 'refresh');
            }
            
        }else{
            $this->load->view('admin/login',$data);
        }
    }
	
	//Dashboard with Guests List
	public function dashboard(){
		$data = array();
		if(empty($this->session->userdata['username']) || $this->session->userdata['username']==""){
			redirect(base_url() . 'admin', 'refresh');
		}
		
		$this->db->select("*");
		$this->db->order_by("post_date", "DESC");
		$query = $this->db->get("guest");
		$rows = $query->result();
		$data['guests'] = $rows;
		
		$data['main_content'] = $this->load->view('admin/dashboard', $data, TRUE);
		
        $this->load->view('admin/main_layout', $data);
	}
	
	//Friends
	public function friend($id=""){
		$data = array();
		if(empty($this->session->userdata['username']) || $this->session->userdata['username']==""){
			redirect(base_url() . 'admin', 'refresh');
		}
		
		$data['guest'] = array();
		if(!empty($id) ){
			$this->db->select("*");
			$this->db->where('id', $id);
			$this->db->order_by("post_date", "DESC");
			$query_g = $this->db->get("guest");
			$guest = $query_g->result();
			$data['guest'] = $guest;
			
			$this->db->select("*");
			$this->db->where('guest_id', $id);
			$this->db->order_by("post_date", "DESC");
			$query = $this->db->get("friends");
			$rows = $query->result();
			$data['friends'] = $rows;
		} else {
			$data['friends'] = array();
		}		
		
		$data['main_content'] = $this->load->view('admin/friend_list', $data, TRUE);		
        $this->load->view('admin/main_layout', $data);
	}
	
	//Logout
	function logout(){
        $this->session->sess_destroy();
        $data = array();
        $data['page'] = 'logout';
        $this->load->view('admin/login', $data);
    }
	
}
