<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model{

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function validate_user(){            
        
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->where('username', $this->input->post('username')); 
        $this->db->where('password', $this->input->post('password'));
		$this->db->where('is_active', 1); 
        $this->db->limit(1);
        $query = $this->db->get();   
         
        if($query->num_rows() == 1){  
		
           return $query->result();
        }
        else{
            return false;
        }
    }
	
}
