
    <!-- Start Page Content -->

    <div class="row">
        <div class="col-lg-12">

            
           <div class="panel panel-info">
                <div class="panel-heading"> <i class="fa fa-list"></i> Friends<?php if(!empty($guest)){ echo " of ".$guest[0]->fname." ".$guest[0]->lname; }?></div>
				
                <div class="panel-body table-responsive">
				
				 <?php $msg = $this->session->flashdata('msg'); ?>
            <?php if (isset($msg)): ?>
                <div class="alert alert-success delete_msg pull" style="width: 100%"> <i class="fa fa-check-circle"></i> <?php echo $msg; ?> &nbsp;
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">�</span> </button>
                </div>
            <?php endif ?>

            <?php $error_msg = $this->session->flashdata('error_msg'); ?>
            <?php if (isset($error_msg)): ?>
                <div class="alert alert-danger delete_msg pull" style="width: 100%"> <i class="fa fa-times"></i> <?php echo $error_msg; ?> &nbsp;
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">�</span> </button>
                </div>
            <?php endif ?>
							<table id="example23" class="display nowrap" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                </tr>
                            </tfoot>
                            
                            <tbody>
                            <?php 
							if(empty($friends)){
							?>
							<tr>
                                <td colspan="3"><b>No friend found!!</b></td>
							</tr>		
							<?php 	
							} else {
							
								foreach ($friends as $friend): 
							?>
                                
                                <tr>

                                    <td><?php echo $friend->fname; ?></td>
                                    <td><?php echo $friend->lname; ?></td>
                                    <td><?php echo $friend->email; ?></td>
                                </tr>

                            <?php 
							
								endforeach;
							
							}
								 
								
							?>

                            </tbody>


                        </table>
                    </div>
					<div><a href="<?php echo base_url();?>admin/dashboard"><b>Back</b></a></div>
					
            </div>
        </div>
    </div>

 </div>

    <!-- End Page Content -->