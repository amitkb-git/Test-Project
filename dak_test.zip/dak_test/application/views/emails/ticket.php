<html>
<body>
<center>
    <div style="width:650px;">
        <div style="width: 100%;"><img src="http://redskinsvalidation.dasdak.com/images/hero.jpg"></div>
        <h3 style="margin: 10px 0px 15px 0px;color: #7a1526;font-family: 'Quicksand',sans-serif;"><?php echo $guest_name;?></h3>
        <div style="margin-bottom: 15px; margin-top:-15px; text-align:center; width:100%;">
            <img src="http://redskinsvalidation.dasdak.com/images/promo.gif" style="height: 160px;margin-right: 15px;">
            <img src="http://redskinsvalidation.dasdak.com/barcode/1593596194" height="160px">
			<!-- <img src="<?php //echo base_url();?>img/Barcode.png" height="160px"> -->
        </div>
			<?php 
			 if(!empty($no_of_guests) && $no_of_guests > 0){
			?>
			<h3 style="color: #7a1526;font-family: 'Quicksand',sans-serif;border-bottom: 1px solid #7a1526;padding:0px;width: 66%;margin: 15px 0px 15px 0px;">GUEST BARCODES</h3>
			<div style="margin-top:-15px; text-align:center; width:100%; padding-bottom: 15px;">
			<?php 	
				 for($n=0; $n<$no_of_guests; $n++){
			?>
			<!-- <img style="margin: 9px;" src="<?php //echo base_url();?>img/Barcode.png" height="160px"> -->
			<img src="http://redskinsvalidation.dasdak.com/barcode/1593596194" height="160px">
			<?php 	
				 }
			?>
			</div>
			<?php 	
			 }
			?>
			
            
					
			
			
        <div style="border-bottom: 1px solid #731616; width: 66%; margin-bottom: 10px;"></div>
        <div>
            <img src="http://redskinsvalidation.dasdak.com/images/disclaimer.jpg">
        </div>
        <div>
            <img src="http://redskinsvalidation.dasdak.com/images/app.jpg">
        </div>
        <div>
            <img src="http://redskinsvalidation.dasdak.com/images/roadtrip.jpg">
        </div>
        <div>
            <img src="http://redskinsvalidation.dasdak.com/images/promo.jpg">
        </div>
    </div>
</center>
</body>
</html>