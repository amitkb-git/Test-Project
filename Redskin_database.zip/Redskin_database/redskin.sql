-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2020 at 05:57 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `redskin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `full_name`, `is_active`) VALUES
(1, 'admin', 'admin@123', 'Admin Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `post_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id`, `guest_id`, `fname`, `lname`, `email`, `post_date`) VALUES
(2, 2, 'Amit', 'Matia', 'amitm@gmail.com', NULL),
(3, 2, 'Ases', 'Pramanik', 'asespr@gmail.com', NULL),
(4, 3, 'Zinat', 'Sania', 'zinatsania@comton.in', NULL),
(5, 3, 'Aman', 'Ania', 'amanania@compton.in', NULL),
(6, 4, 'Ratin', 'Sen', 'ratins554@tri.com', '2020-06-26'),
(7, 4, 'Pankaj', 'Dutt', 'pankajr@tri.com', '2020-06-26'),
(8, 5, 'Atin', 'Guha', 'atinguha@teftry.in', '2020-06-26'),
(9, 6, NULL, NULL, NULL, '2020-06-27'),
(10, 10, 'Avi', 'Dhar', 'avi.dhar@gmail.com', '2020-06-27'),
(11, 13, 'Mihir', 'Gupta', 'mihirgupta@gmail.com', '2020-07-01'),
(12, 13, 'Atanu', 'Sen', 'atanusen@gmail.com', '2020-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `id` int(11) NOT NULL,
  `fname` varchar(150) DEFAULT NULL,
  `lname` varchar(150) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `zip_code` varchar(80) DEFAULT NULL,
  `no_of_guest` int(4) DEFAULT 0,
  `free_season_ticket_waitlist` tinyint(1) DEFAULT 0,
  `free_redskin_women_club` tinyint(1) DEFAULT 0,
  `receive_special_offer` tinyint(1) DEFAULT 0,
  `redskin_salute_military` tinyint(1) DEFAULT 0,
  `post_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`id`, `fname`, `lname`, `email`, `zip_code`, `no_of_guest`, `free_season_ticket_waitlist`, `free_redskin_women_club`, `receive_special_offer`, `redskin_salute_military`, `post_date`) VALUES
(2, 'Rohit', 'Das', 'rohitdas65@gmail.com', '87895', 2, 1, 1, 1, 1, NULL),
(3, 'Kinkar', 'Das', 'kinkar@comton.in', '78787', 2, 1, NULL, 1, 1, NULL),
(4, 'Atul', 'Roy', 'atulroy@capital.in', '25436', 2, 1, NULL, 1, 1, '2020-06-26'),
(5, 'Arit', 'Bose', 'aritbose@gmail.com', '24532', 1, 1, 1, 1, NULL, '2020-06-26'),
(6, 'Anik', 'Gupta', 'anik.gpt@gmail.com', '65454', 0, NULL, NULL, NULL, NULL, '2020-06-27'),
(7, 'Tapan', 'Ash', 'tapan.ash75@gmail.com', '98989', 0, 1, 1, NULL, NULL, '2020-06-27'),
(8, 'Kunal', 'Sarkar', 'kunalsk@yahoo.com', '76756', 0, NULL, 1, 1, 1, '2020-06-27'),
(9, 'Paresh', 'Bose', 'paresh.b@gmail.com', '54543', 0, 1, 1, NULL, NULL, '2020-06-27'),
(10, 'Amit', 'Dhar', 'amitdharb@gmail.com', '45621', 0, 1, 1, NULL, NULL, '2020-06-27'),
(12, 'Amit', 'Bhar', 'amitkb.amit@gmail.com', '56443', 0, NULL, NULL, NULL, NULL, '2020-07-01'),
(13, 'Avik', 'Das', 'avikd@gmail.com', '24562', 2, 1, 1, NULL, 1, '2020-07-01'),
(15, 'Amit', 'Bhar', 'amitkb.amit@gmail.com', '43434', 0, NULL, NULL, NULL, NULL, '2020-07-03'),
(16, 'Amit', 'Bhar', 'amitkb.amit@gmail.com', '45454', 0, NULL, NULL, NULL, NULL, '2020-07-04'),
(17, 'Amit', 'Bhar', 'amitkb.amit@gmail.com', '65656', 0, NULL, NULL, NULL, NULL, '2020-07-04'),
(18, 'Atin', 'Nath', 'amitkb.amit@gmail.com', '45674', 0, NULL, NULL, NULL, NULL, '2020-07-04'),
(19, 'Asik', 'Barma', 'amitkb.amit@gmail.com', '24454', 0, NULL, NULL, NULL, NULL, '2020-07-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guest_id` (`guest_id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guest` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
